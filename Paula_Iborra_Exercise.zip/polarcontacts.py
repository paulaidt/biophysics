# PAULA IBORRA DE TOLEDO
# ENERGY ANALYSIS EXERCISE, BIOPHYSICS - BDBI

from Bio.PDB.NeighborSearch import NeighborSearch
from Bio.PDB.PDBParser import PDBParser
from ForceField import VdwParamset
from ResLib import  ResiduesDataLib

import sys
import argparse
import math
import numpy as np 
import matplotlib.pyplot as plt

COVLNK = 2.0
HBLNK  = 3.5

all_polars = [
    'N', 'ND1', 'ND2', 'NE',  'NE1', 'NE2', 'NH1', 'NH2', 'NZ',
    'O', 'OD1', 'OD2', 'OE1', 'OE2', 'OG',  'OG1', 'OH',
    'S', 'SD',  'SG'
]
backbone_polars =  ['N','O']
waternames = ['WAT','HOH']

def main():

    parser = argparse.ArgumentParser(
                prog='polarContacts',
                description='Polar contacts detector'
            )

    parser.add_argument(
        '--backonly',
        action='store_true',
        dest='backonly',
        help='Restrict to backbone'
    )

    parser.add_argument(
        '--nowats',
        action='store_true',
        dest='nowats',
        help='Exclude water molecules'
    )
    
    parser.add_argument(
        '--diel',
        type= float,
        action='store',
        dest='diel',
        default = 1.0,
        help='Relative dielectric constant'
    )
    
    parser.add_argument(
        '--vdw',
        action='store',
        dest='vdwprm',
        help='VDW Paramters file'
    )
    
    parser.add_argument(
        '--rlib',
        action='store',
        dest='reslib',
        help='AminoAcid library'
    )

    #NEW(1)
    parser.add_argument(
        '--contactsA',
        action='store',
        dest='contact_energies',
        help='List of the 5 most stable contacts'
    )
    #END NEW(1)

    #NEW(2)

    parser.add_argument(
        '--interactionsB',
        action='store_true',
        dest='plot_contacts',
        help='plot main chain / side chain'
    )
    #END NEW(2)

    parser.add_argument('pdb_path')

    args = parser.parse_args()

    print ("Settings")
    print ("--------")
    for k,v in vars(args).items():
        print ('{:10}:'.format(k),v)

    backonly = args.backonly
    nowats =args.nowats
    pdb_path = args.pdb_path
    vdwprm = args.vdwprm
    reslib = args.reslib
    diel = args.diel
    contact_energies = args.contact_energies
    plot_contacts = args.plot_contacts
    
# Load VDW parameters
    vdwParams = VdwParamset(vdwprm)
    print ("{} atom types loaded".format(vdwParams.ntypes))

# Load AA Library
    aaLib = ResiduesDataLib(reslib)
    print ("{} amino acid atoms loaded".format(aaLib.nres))
    
    if not pdb_path:
        parser.print_help()
        sys.exit(2)

    parser = PDBParser(PERMISSIVE=1)

    try:
        st = parser.get_structure('st', pdb_path)
    except OSError:
        print ("#ERROR: loading PDB")
        sys.exit(2)

# Checking for models
    if len(st) > 1:
        print ("#WARNING: Several Models found, using only first")

# Using Model 0 any way
    st = st[0]

# Making a list of polar atoms
    polats = []
    if backonly:
        selected_atoms = backbone_polars

    else:
        selected_atoms = all_polars

    for at in st.get_atoms():
        if at.id in selected_atoms:
            polats.append(at)



#Searching for contacts under HNLNK on diferent residues
    nbsearch = NeighborSearch(polats)
    hblist = []
    for at1, at2 in nbsearch.search_all(HBLNK):
        if at1.get_parent() == at2.get_parent():
            continue
 #Discard covalents and neighbours
        if (at1-at2) < COVLNK:
            continue
        if abs(at2.get_parent().id[1] - at1.get_parent().id[1]) == 1:
            continue
# remove waters
        if nowats:
            if at1.get_parent().get_resname() in waternames \
                or at2.get_parent().get_resname() in waternames:
                continue
                
   #     atom1 = Atom(at1,1,aaLib,vdwParams)
   #     atom2 = Atom(at2,1,aaLib,vdwParams)        
        if at1.get_serial_number() < at2.get_serial_number():
            hblist.append([at1, at2])
        else:
            hblist.append([at2, at1])
       
    print ()
    print ("Polar contacts")
    print ('{:13} {:13} {:6} '.format(
            'Atom1','Atom2','Dist (A)')
    )
    

    for hb in sorted (hblist,key=lambda i: i[0].get_serial_number()):
        r1 = hb[0].get_parent()
        r2 = hb[1].get_parent()
        print ('{:14} {:14} {:6.3f} '.format(
            r1.get_resname()+' '+str(r1.id[1])+hb[0].id,
            r2.get_resname()+' '+str(r2.id[1])+hb[1].id,
            hb[0] - hb[1]
            )
        )


    print ()
    print ("Residue interactions")

# Making list or residue pairs to avoid repeated pairs
    respairs = []
    for hb in hblist:
        r1 = hb[0].get_parent()
        r2 = hb[1].get_parent()
        if [r1,r2] not in respairs:
            respairs.append([r1,r2])

   
    l = []   
    for rpair in sorted(respairs, key=lambda i: i[0].id[1]):            
        eint=0.
        evdw=0.
        for at1 in rpair[0].get_atoms():
            resid1 = rpair[0].get_resname()
            atid1 = at1.id
            atparam1 = aaLib.getParams(resid1,atid1)
            vdwprm1 = vdwParams.atTypes[atparam1.atType]
            for at2 in rpair[1].get_atoms():
                resid2 = rpair[1].get_resname()
                atid2 = at2.id
                atparam2 = aaLib.getParams(resid2,atid2)
                vdwprm2 = vdwParams.atTypes[atparam2.atType]
                eint = eint + 332.16 * atparam1.charg * atparam2.charg/diel/(at1-at2)
                eps = math.sqrt(vdwprm1.eps*vdwprm2.eps)
                sig = math.sqrt(vdwprm1.sig*vdwprm2.sig)
                evdw = evdw + 4 * eps *( (sig/(at1-at2))**12-(sig/(at1-at2))**6)
        print (resid1,rpair[0].id[1],resid2,rpair[1].id[1],eint,evdw) 


        l.append([resid1,rpair[0].id[1],resid2,rpair[1].id[1],eint,evdw, eint+evdw])

    #NEW(1)(2), for --contactsA, --interactionsB

    nres1 = []
    e_int = []
    e_vdw = []
    e_gl = []


    if contact_energies is not None:
        for i, element in enumerate(sorted(l, key=lambda i: i[6])):
                if i < int(contact_energies):
                     print(element)

                     nres1.append(element[0]+element[2])
                     e_int.append(element[4])
                     e_vdw.append(element[5])
                     e_gl.append(element[6])
                             
    n=5
    ind = np.arange(n)
    width = 0.25
    p1 = plt.bar(ind + 0.00, e_int, width, color = 'red')
    p2 = plt.bar(ind + 0.25, e_vdw, width, color = 'green')
    p3 = plt.bar(ind + 0.50, e_gl, width, color = 'blue')
    plt.title('5 most stable contacts')
    plt.legend((p1[0], p2[0], p3[0]), ('E.int', 'E.vdw', 'E.global'))    
    plt.xticks(ind, (nres1[0], nres1[1], nres1[2], nres1[3], nres1[4]))        
    plt.show()


    mmx = [] #mm: main - main interaction
    mmy = [] 
    ssx = [] #ss: side -side interaction
    ssy = []
    msx = [] #ms: main - side interaction
    msy = []
    if plot_contacts:
        for hb in sorted (hblist,key=lambda i: i[0].get_serial_number()):
            if hb[0].id in backbone_polars and hb[1].id in backbone_polars:
                chain0 = 'm'
                chain1 = 'm'
            elif hb[0].id in backbone_polars and not hb[1].id in backbone_polars:
                chain0 = 'm'
                chain1 = 's'
            elif not hb[0] in backbone_polars and not hb[1].id in backbone_polars:
                chain0 = 's'
                chain1 = 's'

            if chain0 == 'm' and chain1 =='m':
                val = 1
                mmx.append(hb[0].get_parent().id[1])
                mmy.append(hb[1].get_parent().id[1])
            elif chain0 == 's' and chain1 == 's':
                val = 2 
                ssx.append(hb[0].get_parent().id[1])
                ssy.append(hb[1].get_parent().id[1])
            else:
                val = 3 
                msx.append(hb[0].get_parent().id[1])
                msy.append(hb[1].get_parent().id[1])

        plt.figure(figsize = (7,7))
        plt.scatter(mmx,mmy, c='green', label= 'Both main chain')
        plt.scatter(ssx,ssy, c='red', label = 'Both side chain')
        plt.scatter(msx, msy, c='blue', label = 'Side - Main chain')
        plt.title('Interactions')
        plt.ylabel('#Residue2')
        plt.xlabel('#Residue1')
        plt.legend(loc = 'lower right')
        plt.show()

    #END NEW(1)(2)

if __name__ == "__main__":
    main()
